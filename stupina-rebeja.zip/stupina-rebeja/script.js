// Language toggle (RU / RO)
document.addEventListener('DOMContentLoaded', function(){
  const btnRu = document.getElementById('btn-ru')
  const btnRo = document.getElementById('btn-ro')
  const ruEls = document.querySelectorAll('[data-ru]')
  const roEls = document.querySelectorAll('[data-ro]')

  function showRu(){
    btnRu.classList.add('active')
    btnRo.classList.remove('active')
    ruEls.forEach(e=>e.style.display='')
    roEls.forEach(e=>e.style.display='none')
  }
  function showRo(){
    btnRo.classList.add('active')
    btnRu.classList.remove('active')
    roEls.forEach(e=>e.style.display='')
    ruEls.forEach(e=>e.style.display='none')
  }

  btnRu.addEventListener('click', showRu)
  btnRo.addEventListener('click', showRo)

  // default Russian
  showRu()
})